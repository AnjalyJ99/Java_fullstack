
package rentapp;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

class Camerasapp implements Comparable<Camerasapp> {
	private int cameraid;
	private String brand;
	private String model;
	private double price;
	private boolean status;

	public Camerasapp(int cameraid, String brand, String model, double price, boolean available) {
		this.cameraid = cameraid;
		this.brand = brand;
		this.model = model;
		this.price = price;
		this.status = available;
	}

	public boolean isAvailable() {
		return status;
	}

	public void setAvailable(boolean available) {
		this.status = available;
	}

	public int getCameraid() {
		return cameraid;
	}

	public String getBrand() {
		return brand;
	}

	public String getModel() {
		return model;
	}

	public double getPrice() {
		return price;
	}

	@Override
	public int compareTo(Camerasapp other) {
		return Integer.compare(this.cameraid, other.cameraid);
	}
}

public class rentalApp {
	public static void main(String[] args) {
		double INR = 1000;
		String username, password;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter username:");
		username = sc.nextLine();
		System.out.println("Enter password:");
		password = sc.nextLine();
		if (username.equals("user") && password.equals("1234")) {
			System.out.println("Successfully Logged In");
			ArrayList<Camerasapp> list = new ArrayList<>();
			list.add(new Camerasapp(10, "Nikon", "DSLR", 500, true));
			list.add(new Camerasapp(11, "Sony", "DSLR12", 200, false));
			list.add(new Camerasapp(12, "Samsung", "SM123", 200, true));
			list.add(new Camerasapp(13, "canon", "DsLR", 2500, true));
			list.add(new Camerasapp(14, "nikon", "D7500", 500, true));
			list.add(new Camerasapp(15, "Lenova", "XPL", 300, false));
			list.add(new Camerasapp(16, "LG", "Digital", 300, true));
			list.add(new Camerasapp(17, "Sony", "XP", 400, false));
			list.add(new Camerasapp(18, "Canon", "DSP", 800, true));
			list.add(new Camerasapp(19, "LG", "DSLR", 900, true));
			int x = 0;
			do {

				int op = 0;
				boolean isValidOption = false;

				System.out.println("1. MY CAMERA");
				System.out.println("2. RENT A CAMERA");
				System.out.println("3. VIEW ALL CAMERAS");
				System.out.println("4. MY WALLET");
				System.out.println("5. EXIT");

				while (!isValidOption) {
					System.out.println("Choose an option:");
					try {
						op = sc.nextInt();
						if (op < 1 || op > 5) {
							throw new InputMismatchException();
						}
						isValidOption = true;
					} catch (InputMismatchException e) {
						System.out.println("Invalid input. Please enter a valid option number.");
						sc.nextLine();
					}
				}
				switch (op) {
				case 1:
					int p = 0;
					do {
						int opt;
						System.out.println("1. ADD");
						System.out.println("2. REMOVE");
						System.out.println("3. VIEW MY CAMERAS");
						System.out.println("4. GO TO PREVIOUS MENU");
						System.out.println("Enter your choice: ");
						try {
							opt = sc.nextInt();
						} catch (InputMismatchException e) {
							System.out.println("invalid input. Please enter a valid option number.");
							sc.nextLine();
							continue;
						}
						switch (opt) {
						case 1:
							System.out.println("Enter Camera ID: ");
							int camera_id;
							try {
								camera_id = sc.nextInt();
							} catch (InputMismatchException e) {
								System.out.println("Invalid input. Camera ID must be an integer.");
								sc.nextLine();
								continue;
							}
							System.out.println("Enter Camera Brand: ");
							String brand = sc.next();
							System.out.println("Enter Camera Model: ");
							String model = sc.next();
							System.out.println("Enter Camera Price per day: ");
							double price;
							try {
								price = sc.nextDouble();
							} catch (InputMismatchException e) {
								System.out.println("Invalid input. Price must be a floating-point number.");
								sc.nextLine();
								continue;
							}
							boolean Available = true;
							list.add(new Camerasapp(camera_id, brand, model, price, Available));
							System.out.println("Added Successfully");
							break;
						case 2:
							System.out.println("Do you want to remove a camera? Enter Camera ID:");
							int cameraId;
							try {
								cameraId = sc.nextInt();
							} catch (InputMismatchException e) {
								System.out.println("Invalid input. Camera ID must be an integer.");
								sc.nextLine(); // Clearing the input buffer
								continue;
							}
							boolean removed = false;
							for (int i = 0; i < list.size(); i++) {
								Camerasapp cam = list.get(i);
								if (cam.getCameraid() == cameraId) {
									list.remove(i);
									removed = true;
									break;
								}
							}
							if (removed) {
								System.out.println("Camera removed successfully.");
							} else {
								System.out.println("Camera with ID " + cameraId + " is not found.");
							}
							break;
						case 3:
							System.out.println(
									"------------------------------------------------------------------------");
							System.out.println("Camera Id\tBrand\t\tModel\t\tPrice\t\tStatus");
							System.out.println(
									"------------------------------------------------------------------------");
							for (int i = 0; i < list.size(); i++) {
								Camerasapp view = list.get(i);
								String data = view.isAvailable() ? "Available" : "Rented";
								System.out.println(view.getCameraid() + "\t\t" + view.getBrand() + "\t\t"
										+ view.getModel() + "\t\t" + view.getPrice() + "\t\t" + data);
							}
							break;
						case 4:
							x = 1;
							break;
						default:
							System.out.println("Invalid option. Please enter a valid option number.");
						}
						System.out.println("Do you want to add or remove a camera? Enter '1' for Yes or '0' for No:");
						boolean isValidInput = false;
						while (!isValidInput) {
							try {
								p = sc.nextInt();
								if (p != 0 && p != 1) {
									throw new InputMismatchException();
								}
								isValidInput = true;
							} catch (InputMismatchException e) {
								System.out.println("Invalid input. Please enter either '1' or '0'.");
								sc.nextLine();
							}
						}
					} while (p == 1);
					break;
				case 2:
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Camera Id\tBrand\t\tModel\t\tPrice\t\tStatus");
					System.out.println("------------------------------------------------------------------------");
					for (Camerasapp datas : list) {
						if (datas.isAvailable()) {
							String status = datas.isAvailable() ? "Available" : "Rented";
							System.out.println(datas.getCameraid() + "\t\t" + datas.getBrand() + "\t\t"
									+ datas.getModel() + "\t\t" + datas.getPrice() + "\t\t" + status);
						}
					}
					int index = -1;
					System.out.println("Which camera do you want to rent? Enter camera ID: ");
					int cameraId;
					try {
						cameraId = sc.nextInt();
					} catch (InputMismatchException e) {
						System.out.println("Invalid input. Camera ID must be an integer.");
						sc.nextLine();
						break;
					}
					for (int i = 0; i < list.size(); i++) {
						Camerasapp camera = list.get(i);
						if (camera.getCameraid() == cameraId) {
							index = i;
							break;
						}
					}
					if (index != -1) {
						Camerasapp a = list.get(index);
						if (a.getPrice() <= INR) {
							System.out.println("Rented Successfully");
							a.setAvailable(false);
							INR = INR - a.getPrice();
							System.out.println("Current wallet balance - " + INR);
						} else {
							System.out.println("You don't have sufficient balance in your wallet.");
						}
					} else {
						System.out.println("Camera with ID " + cameraId + " is not found in the list.");
					}
					break;
				case 3:
					System.out.println("------------------------------------------------------------------------");
					System.out.println("Camera Id\tBrand\t\tModel\t\tPrice\t\tStatus");
					System.out.println("------------------------------------------------------------------------");
					for (int i = 0; i < list.size(); i++) {
						Camerasapp view = list.get(i);
						String data = view.isAvailable() ? "Available" : "Rented";
						System.out.println(view.getCameraid() + "\t\t" + view.getBrand() + "\t\t" + view.getModel()
								+ "\t\t" + view.getPrice() + "\t\t" + data);
					}
					break;
				case 4:
					System.out.println("Your current wallet balance is: " + INR);
					System.out.println("Do you want to deposit more amount? (1. Yes 2. No) - ");
					int m = 0;
					try {
						m = sc.nextInt();
						if (m != 1 && m != 2) {
							throw new InputMismatchException();
						}
					} catch (InputMismatchException e) {
						System.out.println("Invalid input. Please enter either '1' or '2'.");
						sc.nextLine();
					}

					if (m == 1) {
						System.out.println("Enter amount: ");
						double addAmount;
						try {
							addAmount = sc.nextDouble();
						} catch (InputMismatchException e) {
							System.out.println("Invalid input. Amount must be a floating-point number.");
							sc.nextLine();
							break;
						}
						INR = INR + addAmount;
						System.out.print("Your wallet balance updated successfully.");
					}

					System.out.println("Current wallet balance - " + INR);
					break;
				case 5:
					System.out.println("Exited...");
					break;
				default:
					System.out.println("Invalid option. Please enter a valid option number.");
				}
				boolean isValidInput = false;
				while (!isValidInput) {
					System.out.println("Do you want to continue? (1. Yes 2. No) - ");
					try {
						x = sc.nextInt();
						if (x != 1 && x != 2) {
							throw new InputMismatchException();
						}
						isValidInput = true;
					} catch (InputMismatchException e) {
						System.out.println("Invalid input. Please enter either '1' or '2'.");
						sc.nextLine();
					}
				}
			} while (x == 1);
		} else {
			System.out.println("Authentication Failed");
		}
		System.out.println("Thank you for using this app");
	}
}
